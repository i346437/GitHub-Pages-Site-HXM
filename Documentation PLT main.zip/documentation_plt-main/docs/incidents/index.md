---
title: RCA Template
sidebar_position: 1
---
# Technical Deep Dive RCA Template

1. Incident Details:
    - Briefly describe the incident and its impact during the specified timeframe.

2. Description:
    - Provide a detailed description of the incident, including symptoms.

3. Investigation Scope:
    - Define the scope of the investigation, specifying the timeframe and the affected components (e.g., OS, storage, network, tools).

4. Findings:
    - Using a chronological approach, summarize the investigation.

5. Root Cause Analysis:
    - Comment the underlying cause(s) of the incident [may use techniques like the "5 Whys" or fishbone diagrams to identify the root cause(s)]

6. Corrective Actions:
    - Propose corrective actions to address the root cause(s) and prevent similar incidents from occurring in the future. Include specific steps, timelines, and responsible parties.

7. Lessons Learned:
    - Document any lessons learned from the incident, including recommendations for process improvements or additional monitoring/alerting.

8. Conclusion:
     - Summarize the RCA findings and the actions taken to resolve the incident.

9. References:
     - Include any relevant documentation, links, or references used during the investigation.

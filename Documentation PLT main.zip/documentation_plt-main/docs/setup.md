---
id: about-doc
title: About
hide_title: true
# hide_table_of_contents: true
---

## ?

Built to share the knowledge and bring team up to the speed. 

### Backend

Documentation site is built with OSS framework which is approved to use within SAP. 
It is a static site generator that builds a single-page application with fast client-side navigation. It is built using the components: Markdown Files, MDX Processor, React Components, Webpack Bundler and Static Site Output.

### Workflow: Current

Assume we already cloned git documentation repo,

1.  Create/modify/update markdown (.md) files using `vscode` or any editor
2.  Commit and push the changes to repo
3.  Publish the repo using `yarn build`
4.  Copy `build` directory to the published repo which is already serving the url


### Workflow: Future (CI/CD pipeline)

1.  Colleague proposes changes to the doc (EDIT option is enabled)
2.  Upon pull request, the assigned approver reviews the doc and merge it to the original repo
3. Upon merge, the repo contents is built and published to the github page hosting repo


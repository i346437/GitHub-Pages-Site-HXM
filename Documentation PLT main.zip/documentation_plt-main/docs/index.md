---
id: home-page
title: Links
hide_title: true
# hide_table_of_contents: true
---

##### Opening a ticket
- Service Requests/RITM [Catalog](https://sap.service-now.com/sp?id=sc_category) / [GCS Backup and Restore](https://sap.service-now.com/sp?id=sc_category&sys_id=b2a3b5eadb6788d03da8366af4961951&catalog_id=09a3ed6a1b2f80d020c8fddacd4bcb02) / [SFSF Database Requests](https://sap.service-now.com/sp?id=sc_category&sys_id=cbba42e01b936010614e744c8b4bcba7&catalog_id=fdc0c2281bdf2010614e744c8b4bcb50&spa=1) / [GCS Storage](https://sap.service-now.com/sp?id=sc_category&sys_id=6f6f37251b81501020c8fddacd4bcbd7&catalog_id=09a3ed6a1b2f80d020c8fddacd4bcb02&spa=1) / [Network](https://sap.service-now.com/sp?id=sc_cat_item&table=sc_cat_item&sys_id=f636a3d61b1bf410e17a759b9b4bcb43&searchTerm=Network)

##### Troubleshooting:
  - [Suse Cluster](https://confluence.successfactors.com/display/SSADO/HANA+Cluster+Troubleshooting)

##### Jobs:
  - [Enable & Disable HANA backups from DCC](https://confluence.successfactors.com/pages/viewpage.action?pageId=494022442)

##### Essentials:
  - [P1check](https://dbatoolbox.sapsf.com/DBAInventory/HanaP1Check) / 
  [HAWKEYE](https://hana-hawkeye.sapsf.com/hawkeye.html) / 
  [WTS](https://jumphost.citrix-access.global.corp.sap/logon/LogonPoint/tmindex.html) / 
  [Jumphosts](https://confluence.successfactors.com/pages/viewpage.action?spaceKey=SSPS&title=OSS+Administration+Cheatsheet) /
 [Windows Jumphost Load Balancer](https://confluence.successfactors.com/display/SSPS/Windows+Jumphost+Load+Balancer) / 
  [ HANA Dev BUG Tracker](https://sap.sharepoint.com/%3Ax%3A/r/teams/HANAOEM/_layouts/15/doc2.aspx?sourcedoc=%7B092ee5de-5660-41ab-ae4e-2067e22d10f3%7D&action=edit&wdinitialsession=c14458b5-b47d-478b-b721-fe86c977211d&wdrldsc=27&wdrldc=2&wdrldr=BootTimeMismatch)
   
##### Dashboards:
  - Snow [SF HANA SME](https://sap.service-now.com/$pa_dashboard.do?sysparm_dashboard=14afb4e4db53e850dc7a9825f396197c&sysparm_tab=941375c1db27a89028caa02305961944&sysparm_cancelable=true&sysparm_editable=false&sysparm_active_panel=false)

  - Splunk  [HANA SME](https://orf.cld.ondemand.com/en-US/app/database_utilities/hxm_hana_sme_dashboard) / [CPU](https://orf.cld.ondemand.com/en-US/app/database_utilities/hana_cpu_analysis) / [Crashdump](https://orf.cld.ondemand.com/en-US/app/database_utilities/hana_crash_dump_file_analysis) / [HANA Trace](https://orf.cld.ondemand.com/en-us/app/database_utilities/hana_trace_analysis)
  
  - Standup [EMEA](https://sap.sharepoint.com/sites/117570/SitePages/Presentation%20Page.aspx?location=EMEA) / [APJ](https://sap.sharepoint.com/sites/117570/SitePages/Presentation%20Page.aspx?location=APJ) / [AMS](https://sap.sharepoint.com/sites/117570/SitePages/Presentation%20Page.aspx?location=AMS) / [ALL](https://sap.sharepoint.com/sites/117570/SitePages/Presentation%20Page.aspx) / [Service Review](https://confluence.successfactors.com/pages/viewpage.action?spaceKey=IMC&title=Service+Review+Meeting)

  - Others [HANA Inventory](https://itoahana.sapsf.com/inventory/prod/) / [Shift OSM](https://osm.cfapps.us10.hana.ondemand.com/shift-matrix) / [SISM](https://cmp.wdf.sap.corp/sesi/main/#)

##### Other links:
  - Github [DBOps](https://github.tools.sap/sdo-dbops) / [SME](https://github.tools.sap/sdo-dbops/hana-sys-sme) / [EUCFDBA](https://github.tools.sap/eucfdba)

##### CAM Access Profiles:
  - HANA DBA
    - [SAPSF_A_DBAHANA_DBACCESS_EUDPADMIN](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_A_DBAHANA_DBACCESS_EUDPADMIN) - Gives admin access to HANA DB level for EU Datacenters
    - [SAPSF_P-HDB-ADMIN-NONEU](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_P-HDB-ADMIN-NONEU) - Profile for HANA Admin access - Used by HDB Admin Team
    - [SAPSF_P-HDB-ADMIN-EU](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_P-HDB-ADMIN-EU) - Profile for EU HANA DB Admin access - Used by HDB Admin Team EU
    - [SAPSF_T-DBAHANA_Admin](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_T-DBAHANA_Admin) - OS Access Gives full Admin rights to all Systems in the Datacenters
    - [SAPSF_T-DBAHANA_EUR_EUDPAdmin](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_T-DBAHANA_EUR_EUDPAdmin) - OS Access Gives full Admin rights to all Systems in european Datacenters (includes EUDP rights)
      - [SAPSF_EUDP_CAM_ACCESS](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_EUDP_CAM_ACCESS) - Get this profile approved first in order to get access via above profile.
  - Azure
    - [Azure_SAPSharedTenant](https://spc.ondemand.com/cam/ui/admin?item=request&profile=Azure_SAPSharedTenant) - Members of this profile will have a guest account provisioned in the Multi Cloud Azure SAP Shared Tenant
  - Converged Cloud
    - [CC HCM Openstack Domain Access](https://spc.ondemand.com/cam/ui/admin?item=request&user=I348761&profile=CC%20HCM%20Openstack%20Domain%20Access#) - Get access to the Converged Cloud Openstack hcm Domain
    - [CC HCM Openstack Domain Operator](https://spc.ondemand.com/cam/ui/admin?item=request&profile=CC%20HCM%20Openstack%20Domain%20Operator) - Get read-only access to SF Data Centers in HCM Domain for Converged Cloud
    - [CC MONSOON3 Openstack Domain Access](https://spc.ondemand.com/cam/ui/admin?item=request&profile=CC%20MONSOON3%20Openstack%20Domain%20Access) - Get access to the Converged Cloud Openstack Monsoon3 and Global Domain	
    - [CC HCM EU-DE-1 Automation Project Admins](https://spc.ondemand.com/cam/ui/admin?item=request&profile=CC%20HCM%20EU-DE-1%20Automation%20Project%20Admins) - Get access to Automation Projects in Region EU-DE-1
    - [Cloud Infrastructure Services SFSF](https://spc.ondemand.com/cam/ui/admin?item=request&profile=Cloud%20Infrastructure%20Services%20SFSF) - Access to CIS - SaaS landscape(s) for SFSF teams
    - [Development Landscape - HCM Engineering](https://spc.ondemand.com/cam/ui/admin?item=request&profile=Development%20Landscape%20-%20HCM%20Engineering) - Access to HCM services for engineering teams in development landscape
    - [SAPSF_T-HCMLAB_EU_DE_DC025_Admin](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_T-HCMLAB_EU_DE_DC025_Admin) - Admin Access to HCMLAB Team(Grants full access only at project level)
  - Tools  
    - Git
      - [SAPSF_A-GIT_OPERATOR](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_A-GIT_OPERATOR) - SAPSF GITHUB ACCESS for DEVELOPMENT
    - Infrastructure Automation
      - [SAPSF_A-INFRA_BUILD_HANA_APPROVER](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_A-INFRA_BUILD_HANA_APPROVER) - Gives HANA build related operations in Jenkins
      - [SAPSF_A-INFRA_BUILD_HANA_OPERATOR](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_A-INFRA_BUILD_HANA_OPERATOR) - Gives Infra build operator access to HANA Module
    - Splunk
      - [SAPSF_A-SPLK_Operator](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_A-SPLK_Operator) - This profile grants Operator access to Splunk in all datacenters
      - [SAPSF_A-SPLK_Read](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_A-SPLK_Read) - This profile grants Read access to Splunk in all Datacenters.
      - [SAPSF_A-SPLK_Power](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_A-SPLK_Power) - This profile grants Power User access to Splunk in all datacenters
    - Tanium
        - [SAPSF_A-Tanium_ReadOnly](https://spc.ondemand.com/cam/ui/admin?item=request&user=I348761&profile=SAPSF_A-Tanium_ReadOnly) - Provide Read only access to Tanium
        - [SAPSF_A-Vulnerability_ReadOnly](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_A-Vulnerability_ReadOnly) - Provide access to vulnerability management space in ELK
    - FRUN
      - [SAPSF_P_FRUN-OPERATOR-DBA](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_P_FRUN-OPERATOR-DBA)
      - [SAPSF_P_FRUN-ADMIN](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_P_FRUN-ADMIN)
    - DB Tools
      - [SAPSF_P-HANA-SIDGEN-USER](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_P-HANA-SIDGEN-USER) - HANA SID generator tool access
   
  - Other
    - [Cloud Access Manager (Production)](https://spc.ondemand.com/cam/ui/admin#) - CAM tool
    - [Cloud Reporting Basic Access](https://spc.ondemand.com/cam/ui/admin?item=request&profile=Cloud%20Reporting%20Basic%20Access) - Basic Access to the Cloud Reporting (RZA): https://reporting.ondemand.com/sap/crp/cdo
    - [SAPSF_EUDP_CAM_ACCESS](https://spc.ondemand.com/cam/ui/admin?item=request&profile=SAPSF_EUDP_CAM_ACCESS) - Profile to restrict EUDP access. ONLY SUPPORT TEAMS IN EU ARE ELIGABLE TO REQUEST
  
  
  





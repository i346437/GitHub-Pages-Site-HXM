---
title: Jobs
hide_title: true
---

#### HANA Upgrade
```bash
$ cd /home/ansible/ansible/balu/Upgrade
$ ansible-playbook -i bbs_inv upgrade_dr_new.yml
```











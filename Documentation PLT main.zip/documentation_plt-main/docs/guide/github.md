---
title: GitHub
hide_title: true
---

Exclude specific files from git maintanance.
    remove files from target as necessary.
    ```sh
    find scripts/ak -type f -name '*.zip' -exec rm {} +
    ```
    add path to .gitignore
    ```sh
    scripts/ak/**/*.zip
    ```

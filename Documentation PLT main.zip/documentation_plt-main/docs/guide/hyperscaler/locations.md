---
title: Datacenters
hide_title: true
---
Ref# [Azure Regions](https://www.azurespeed.com/Information/AzureRegions)
| DC   | Region            | Location           |Usage
|------|-------------------|--------------------|----
| DC01 | West US 2         | Washington         |
| DC60 | Canada Central    | Toronto            |
| DC61 | Canada East       | Quebec             |DR for DC60
| DC62 | Brazil South      | São Paulo State    |
| DC66 | Australia East    | New South Wales    |
| DC67 | Australia Southeast | Victoria         |DR for DC66
| DC68 | East US 2         | Virginia           |
| DC69 | West US 2         | Washington         |DR for DC68
| DC70 | East US 2         | Virginia           |
| DC71 | West US 2         | Washington         |DR for DC70
| DC74 | Switzerland North | Zürich             |
| DC75 | Switzerland West  | Geneva             |DR for DC74

Ref# [Google Regions](https://www.economize.cloud/resources/gcp/regions-zones-map/)
| DC   | Region           | Location   | Usage     |
|------|------------------|------------|-----------|
DC50, asia-northeast1-a/c, Tokyo
| DC55 | europe-west3-a/b  | Frankfurt  |           |
| DC57 | europe-west4-a/b   | Eemshaven  |           |

Ref# [Converged Cloud]



todo: portal links
---
title: HANA Scale-Up (1+1) Cluster Using SUSE with Pacemaker
hide_title: true
---

## Architecture


1. **Primary and Secondary Nodes**:
   - **Node 1 (Primary)**: Runs the SAP HANA database in an active state.
   - **Node 2 (Secondary)**: Acts as a standby and takes over if the primary node fails.

2. **Pacemaker Cluster**:
   - Manages the high availability cluster, ensuring failover from the primary to the secondary node.
   - Corosync is used for cluster communication and quorum.

3. **STONITH**:
   - Implements fencing to isolate a failed node and prevent split-brain scenarios, ensuring data consistency.

4. **Network File System (NFS)**:
   - Used for HANA data, backups, and log volumes, which are not shared directly between the cluster nodes but managed individually.

5. **SYNCMEM for HANA**:
   - Ensures memory synchronization between the primary and secondary HANA nodes, enhancing data replication and consistency.

6. **Cluster Resources**:
   - **SAP HANA Database**: The primary resource managed by Pacemaker.
   - **Virtual IP (VIP)**: Provides a consistent IP address for client access, regardless of the active node.

7. **Network**:
   - High-speed network connections between the nodes for data replication and cluster communication.
   - Separate network for client access and cluster management.

## Configuration Steps

1. **Install SUSE Linux Enterprise Server (SLES) on both nodes**:
   - Install SUSE Linux Enterprise Server and the High Availability Extension on both nodes:
     ```bash
     sudo zypper install -t pattern ha_sles
     ```

2. **Install and configure SAP HANA on both nodes**:
   - Follow the SAP HANA installation guide for SLES to set up HANA on both nodes.

3. **Install Pacemaker and Corosync on both nodes**:
   - These should already be installed with the HA pattern from step 1. Verify installation:
     ```bash
     sudo zypper install -t pattern ha_sles
     ```

4. **Configure Corosync for cluster communication**:
   - Edit the Corosync configuration file `/etc/corosync/corosync.conf` to define the cluster nodes and communication settings.

5. **Configure STONITH for fencing**:
   - Set up STONITH devices to ensure proper node isolation in case of failure.
   - Example configuration for an IPMI-based STONITH device:
     ```bash
     crm configure primitive stonith-sbd stonith:external/sbd \
         params pcmk_host_list="node1 node2"
     crm configure property stonith-enabled=true
     ```

6. **Configure Pacemaker resources for HANA and VIP**:
   - Define resources for the HANA database and VIP.
   - Example configuration:
     ```bash
     crm configure primitive vip ocf:heartbeat:IPaddr2 \
         params ip="192.168.1.100" cidr_netmask="24" op monitor interval="30s"
     crm configure primitive hana ocf:heartbeat:SAPInstance \
         params InstanceName="HDB00" SID="HDB" op monitor interval="30s"
     crm configure colocation col-hana-with-vip inf: hana vip
     crm configure order ord-hana-after-vip inf: vip:start hana:start
     ```

7. **Set up NFS for HANA data, backups, and logs**:
   - Ensure that NFS is configured correctly on both nodes and that the necessary mounts are set up.

8. **Enable SYNCMEM for HANA**:
   - Configure HANA for SYNCMEM replication between the primary and secondary nodes as per the SAP HANA Administration Guide.

9. **Test failover scenarios**:
   - Simulate failures to ensure that the secondary node takes over correctly and that the VIP is reassigned properly.

This configuration ensures a robust high availability setup for SAP HANA on SUSE Linux Enterprise Server with Pacemaker, utilizing NFS for data storage and SYNCMEM for memory synchronization.

---
title: Corosync config
hide_title: true
---

The `/etc/corosync/corosync.conf` file is the main configuration file for Corosync, which is used for cluster communication in a Pacemaker-managed high availability cluster. Below is an example configuration file and a detailed explanation of its contents:

## Example Configuration

```plaintext
totem {
    version: 2
    secauth: on
    cluster_name: my_cluster
    transport: udpu
    interface {
        ringnumber: 0
        bindnetaddr: 192.168.1.0
        mcastaddr: 239.255.1.1
        mcastport: 5405
    }
    consensus: 3600
}

logging {
    to_syslog: yes
    debug: off
}

quorum {
    provider: corosync_votequorum
    two_node: 1
}

nodelist {
    node {
        ring0_addr: node1
        nodeid: 1
    }
    node {
        ring0_addr: node2
        nodeid: 2
    }
}
```

## Explanation of Sections

### `totem`

The `totem` section defines the transport protocol and the network settings for cluster communication.

- `version`: The version of the configuration format. It should be set to 2.
- `secauth`: Enables or disables secure authentication. Setting it to `on` enables it.
- `cluster_name`: The name of the cluster.
- `transport`: Defines the transport mechanism. `udpu` stands for UDP Unicast, which is typically used for smaller clusters.
- `interface`: Specifies the network interface details.
  - `ringnumber`: The ring number for the network interface.
  - `bindnetaddr`: The network address to bind to. This should be the address of the local network (e.g., `192.168.1.0`).
  - `mcastaddr`: The multicast address for communication. This is used if multicast is enabled.
  - `mcastport`: The port number for multicast communication.
- `consensus`: The time (in milliseconds) that Corosync waits for consensus (agreement among cluster nodes) before starting an election to choose a new coordinator. For example, 3600 milliseconds.


### `logging`

The `logging` section controls logging options.

- `to_syslog`: Specifies whether to log to syslog. `yes` enables logging to syslog.
- `debug`: Enables or disables debug logging. `off` disables debug logging.

### `quorum`

The `quorum` section defines quorum settings, which are used to ensure that only a majority of nodes can make decisions.

- `provider`: Specifies the quorum provider. `corosync_votequorum` is the standard provider.
- `two_node`: Special setting for two-node clusters. Setting it to `1` enables special handling for two-node clusters to prevent split-brain scenarios.

### `nodelist`

The `nodelist` section lists all the nodes in the cluster and their addresses.

- `node`: Defines an individual node in the cluster.
  - `ring0_addr`: The address of the node. This should be the hostname or IP address of the node.
  - `nodeid`: A unique identifier for the node.

### Additional Notes

- The `totem` section is crucial for defining how the cluster nodes communicate with each other. Ensure that `bindnetaddr` matches your network configuration.
- The `logging` section helps in monitoring and troubleshooting cluster issues.
- The `quorum` settings are especially important in a two-node cluster to avoid split-brain scenarios.
- The `nodelist` section must accurately reflect all nodes in your cluster, with correct addresses and unique IDs.

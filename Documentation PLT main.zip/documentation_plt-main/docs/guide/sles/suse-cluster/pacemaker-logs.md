---
title: Pacemaker logs
hide_title: true
---

Monitoring and troubleshooting SAP HANA clusters managed by Pacemaker involves examining various logs to understand the cluster's behavior and diagnose issues. Below are key logs and their locations, along with a brief explanation of their contents and significance.

## Key Pacemaker Log Files

### 1. `/var/log/pacemaker.log`

- **Description**: The primary log file for Pacemaker.
- **Contents**: This log file contains detailed information about cluster activities, including resource actions, cluster status changes, and events related to SAP HANA.
- **Usage**: Check this log to understand the sequence of events leading up to an issue, resource start/stop operations, failovers, and other cluster activities.

### 2. `/var/log/messages` or `/var/log/syslog`

- **Description**: General system log file that captures messages from various system components, including Pacemaker and Corosync.
- **Contents**: Contains kernel messages, system messages, and logs from various daemons, including those from the Pacemaker cluster.
- **Usage**: Look here for high-level system events and errors that may affect the cluster, such as network issues, node reboots, and other critical events.

### 3. `/var/log/corosync/corosync.log`

- **Description**: The log file for Corosync, the cluster communication layer used by Pacemaker.
- **Contents**: Contains messages related to cluster communication, quorum changes, and membership changes.
- **Usage**: Useful for diagnosing communication issues between cluster nodes and verifying that Corosync is operating correctly.

## Important Pacemaker Commands for Log Analysis

### Viewing Logs

- **View recent logs**:
  ```bash
  tail -f /var/log/pacemaker.log

- **View logs with specific keywords (e.g., HANA)**:
  ```bash
  grep HANA /var/log/pacemaker.log

### Checking Cluster Status

- **View current cluster status:**:
  ```bash
    crm status

- **View detailed cluster status with resource history::**:
  ```bash
    crm_mon -1 -A -V

### Analyzing Failures

- **View resource operation history:**
    ```bash
    crm resource status <resource_name>
    ```

- **View failed actions:**
    ```bash
    crm_failcount --all --node <node_name>

### Example Log Entries and Their Significance

- **Resource Start/Stop Actions**
  ```bash
  2024-05-22T10:15:25.123456+00:00 node1 pacemaker-controld[1234]: notice: Result of start operation for HANA_HDB_HDB00 on node1: 0 (ok)
  ```
    Indicates that the SAP HANA resource HANA_HDB_HDB00 was successfully started on node1.

- **Resource Failover**
  ```bash
  2024-05-22T10:20:30.789012+00:00 node1 pacemaker-controld[1234]: notice: Initiating recovery of resource HANA_HDB_HDB00 from node1 to node2
  ```
  Shows that the cluster is initiating a failover of the SAP HANA resource from node1 to node2.

- **Cluster Membership Changes**
  ```bash
  2024-05-22T10:25:45.678901+00:00 node1 corosync[5678]: [QUORUM] Members[2]: 1 2
  2024-05-22T10:25:45.678901+00:00 node1 corosync[5678]: [QUORUM] Sync members[2]: 1 2
  ```
  Indicates that the cluster has detected two members (nodes) and they are in sync.

### Best Practices for Log Management

- Regular Monitoring: Regularly monitor Pacemaker logs to detect and address issues promptly.
- Centralized Logging: Use a centralized logging system (e.g., Splunk) to aggregate and analyze logs from all cluster nodes.
- Log Rotation: Ensure log rotation is configured to manage log file sizes and avoid disk space issues.
- Alerting: Set up alerts for critical log entries (e.g., resource failures) to proactively manage cluster health.


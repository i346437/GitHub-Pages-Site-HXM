---
title: Tips
hide_title: true
---

-   Quick search
    ```spl
    splunk_server_group=dc47* host=*hdb*
    ```

-   Search HANA trace logs (with timestamp)
    ```spl
    splunk_server_group=dc57* host=sc57hdbbbg01 source=*server* earliest="07/26/2024:06:20:00" latest="07/26/2024:06:40:00"
    | rex field=_raw "(\d{2}\:){2}\d{2}\.\d{6}\s+(?<logType>\w)\s+(?<component>\w+)\s+\S+\s+\:\s+(?<message>.{0,100})"
    ```
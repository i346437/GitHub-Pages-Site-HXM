---
title: Email Alerts
hide_title: true
---

#### [Alert] :  Persistence Errors Found!

```sql
[160500]{351046}[255/-1] 2024-07-26 08:22:23.769866 e attributes       AttributeEngine.cpp(00539) :    3: 0x00007f84e0429448 in AttributeEngine::AttributeApi::getOpenIndex(AttributeEngine::AttributeStoreHandle&, TrexBase::IndexName const&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*)+0x3e4 at AttributeEngine/AttributeEngine.h:257 (libhdbcs.so)
4: 0x00007f84e042d4f7 in AttributeEngine::AttributeApi::getOpenAttribute(AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeValueContainerHandle&, TrexBase::IndexName const&, unsigned int, AttributeEngine::AttributeStoreLockMode, AttributeEngine::LazyMode)+0x23 at AttributeEngine/AttributeApi.cpp:2785 (libhdbcs.so)
[102409]{351046}[255/-1] 2024-07-26 08:22:23.769884 e attributes       AttributeEngine.cpp(00539) :    3: 0x00007f84e0429448 in AttributeEngine::AttributeApi::getOpenIndex(AttributeEngine::AttributeStoreHandle&, TrexBase::IndexName const&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*)+0x3e4 at AttributeEngine/AttributeEngine.h:257 (libhdbcs.so)
[160500]{351046}[255/-1] 2024-07-26 08:22:23.769866 e attributes       AttributeEngine.cpp(00539) :    2: 0x00007f84e063abc7 in AttributeEngine::AttributeEngine::openIndexfromStorage(TrexBase::IndexName const&, AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*, AttributeEngine::StoreMapBucket&, ltt::smartptr_handle<AttributeEngine::AttributeStore>&)+0x113 at AttributeEngine/AttributeEngine.cpp:527 (libhdbcs.so)
[102409]{351046}[255/-1] 2024-07-26 08:22:23.769884 e attributes       AttributeEngine.cpp(00539) :    2: 0x00007f84e063abc7 in AttributeEngine::AttributeEngine::openIndexfromStorage(TrexBase::IndexName const&, AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*, AttributeEngine::StoreMapBucket&, ltt::smartptr_handle<AttributeEngine::AttributeStore>&)+0x113 at AttributeEngine/AttributeEngine.cpp:527 (libhdbcs.so)
[160500]{351046}[255/-1] 2024-07-26 08:22:23.769866 e attributes       AttributeEngine.cpp(00539) :    1: 0x00007f84e0639c11 in AttributeEngine::AttributeStore::AttributeStore(ltt::allocator&, TrexBase::IndexName const&, PersistenceLayer::IndexStorageLocation const&, bool, DataAccess::PersistenceSession*, bool, bool, bool)+0x440 at AttributeEngine/AttributeStore.cpp:1288 (libhdbcs.so)
[102409]{351046}[255/-1] 2024-07-26 08:22:23.769884 e attributes       AttributeEngine.cpp(00539) :    1: 0x00007f84e0639c11 in AttributeEngine::AttributeStore::AttributeStore(ltt::allocator&, TrexBase::IndexName const&, PersistenceLayer::IndexStorageLocation const&, bool, DataAccess::PersistenceSession*, bool, bool, bool)+0x440 at AttributeEngine/AttributeStore.cpp:1288 (libhdbcs.so)
[160500]{351046}[255/-1] 2024-07-26 08:22:23.769866 e attributes       AttributeEngine.cpp(00539) : :PersistenceSession*, bool, bool, bool)+0x440 at AttributeEngine/AttributeStore.cpp:1288 (libhdbcs.so)
   5: 0x00007f84e063abc7 in AttributeEngine::AttributeEngine::openIndexfromStorage(TrexBase::IndexName const&, AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*, AttributeEngine::StoreMapBucket&, ltt::smartptr_handle<AttributeEngine::AttributeStore>&)+0x113 at AttributeEngine/AttributeEngine.cpp:527 (libhdbcs.so)
   6: 0x00007f84e0429448 in AttributeEngine::AttributeApi::getOpenIndex(AttributeEngine::AttributeStoreHandle&, TrexBase::IndexName const&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*)+0x3e4 at AttributeEngine/AttributeEngine.h:257 (libhdbcs.so)
   7: 0x00007f84e042d4f7 in AttributeEngine::AttributeApi::getOpenAttribute(AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeValueContainerHandle&, TrexBase::IndexName const&, unsigned int, AttributeEngine::AttributeStoreLockMode, AttributeEngine::LazyMode)+0x23 at AttributeEngine/AttributeApi.cpp:2785 (libhdbcs.so)
   8: 0x00007f84e0430a91 in AttributeEngine::AttributeApi::getStatistics(AttributeEngine::AttributeStatistics&)+0x90 at AttributeEngine/AttributeApi.cpp:934 (libhdbcs.so)
   9: 0x00007f84f073ec4c in TRexAPI::JERequestHandler::do_getAttributes(TrexBase::IndexName const&, ltt_adp::vector<ltt_adp::basic_string<char, ltt::char_traits<char>, ltt::integral_constant<bool, true> >, ltt::integral_constant<bool, true> > const&, ltt_adp::vector<JoinEvaluator::AttributeInfo, ltt::integral_constant<bool, true> >&, bool)+0x8f8 at ims_search_api/JERequestHandler.cpp:1556 (libhdbcsapi.so)
  10: 0x00007f84f073fbd9 in TRexAPI::JERequestHandler::getAttributes(TRexUtils::HostAndPort&, TrexBase::IndexName const&, ltt_adp::vector<ltt_adp::basic_string<char, ltt::char_traits<char>, ltt::integral_constant<bool, true> >, ltt::integral_constant<bool, true> > const&, ltt_adp::vector<JoinEvaluator::AttributeInfo, ltt::integral_constant<bool, true> >&, bool)+0x135 at ims_search_api/JERequestHandler.cpp:253 (libhdbcsapi.so)
  11: 0x00007f84f0fc1ea1 in JoinEvaluator::IndexInfo::getAttributeInfo(ltt_adp::basic_string<char, ltt::char_traits<char>, ltt::integral_constant<bool, true> > const&, ltt::releasable_handle<JoinEvaluator::AttributeInfo>&, bool)+0x220 at JoinEvaluator/IndexInfo.cpp:126 (libhdbcsapi.so)
  12: 0x00007f84f11e2131 in JoinEvaluator::CheckAttributes::run()+0x11e0 at JoinEvaluator/CheckAttributes.cpp:221 (libhdbcsapi.so)
  13: 0x00007f84f112772c in JoinEvaluator::JoinEvaluator::checkParts(JoinEvaluator::QueryInfo&)+0x758 at JoinEvaluator/JoinEvaluator.cpp:678 (libhdbcsapi.so)
  14: 0x00007f84f112a2a1 in JoinEvaluator::JoinEvaluator::evaluate(JoinEvaluator::QueryInfo&)+0x3b0 at JoinEvaluator/JoinEvaluator.cpp:300 (libhdbcsapi.so)
  15: 0x00007f84f099bf66 in TRexAPI::TRexApiSearch::searchJoinIndex(TRexAPI::QueryContext&, TRexAPI::TRexApiSearchTableResult&, ltt_adp::vector<TRexAPI::FSTermAttributeInfo, ltt::integral_constant<bool, true> > const*, ltt_adp::vector<TRexConfig::TableOrView, ltt::integral_constant<bool, true> > const&)+0x37d2 at ims_search_api/TRexApiSearch.cpp:9087 (libhdbcsapi.so)
  16: 0x00007f84f09ab145 in TRexAPI::TRexApiSearch::doSearch(TRexAPI::TRexApiSearchTableResult&)+0x4c41 at ims_search_api/TRexApiSearch.cpp:5892 (libhdbcsapi.so)
  17: 0x00007f84f097043f in TRexAPI::TRexApiSearch::search(TRexAPI::TRexApiSearchTableResult&)+0x5b at ims_search_api/TRexApiSearch.cpp:4935 (libhdbcsapi.so)
  18: 0x00007f84f0583ac1 in TRexAPI::JoinSearchImpl::executeSearch(Execution::Context&, TRexAPI::PreparedQuery const&, TRexAPI::QueryRuntime&, ltt::smartptr_handle<TRexCommonObjects::InternalTableBase>&)+0xbf0 at ims_search_api/Search/JoinSearchImpl.cpp:311 (libhdbcsapi.so)
  19: 0x00007f84f05bf5fd in TRexAPI::SearchAPI::extractResults(Execution::Context&, TRexAPI::Search::RowProjectors*, TRexAPI::Search::RawResultContext*)+0xc9 at ims_search_api/Search/SearchAPI.cpp:339 (libhdbcsapi.so)
  20: 0x00007f84f05d6f5b in TRexAPI::SearchAPI::fetchAll(Execution::Context&, bool)+0x27 at ims_search_api/Search/SearchAPI.cpp:973 (libhdbcsapi.so)
  21: 0x00007f84f6ab9cd4 in ptime::TrexOltpSearch::search(Execution::Context&, bool)+0xa0 at ptime/query/plan_executor/trex_wrapper/trex_wrapper_body/trex_oltp_query.cc:228 (libhdbcswrapper.so)
  22: 0x00007f84eb096e47 in ptime::Trex_oltp_search::do_open(ptime::OperatorEnv&, ptime::QEParams, int) const+0x3b3 at ptime/query/plan_executor/dml/external/qe_trex_search.cc:3445 (libhdbrskernel.so)
  23: 0x00007f84ead9dfc0 in ptime::Table::open(ptime::Env&, ptime::QEParams, int) const+0x1c0 at ptime/query/plan_executor/dml/qe_table.cc:194 (libhdbrskernel.so)
  24: 0x00007f84f6a14d48 in ptime::TrexPlanOp::executePtimeOp(ltt_adp::vector<Executor::PlanData*, ltt::integral_constant<bool, true> > const&, ltt_adp::vector<Executor::PlanData*, ltt::integral_constant<bool, true> > const&, TRexCommonObjects::TRexApiError&, Executor::ExecutionInfo const&)+0x2f4 at ptime/query/plan_executor/trex_wrapper/trex_wrapper_body/trex_plan.cc:520 (libhdbcswrapper.so)
  25: 0x00007f84f6a15477 in ptime::TrexPlanOp::executePop(ltt_adp::vector<Executor::PlanData*, ltt::integral_constant<bool, true> > const&, ltt_adp::vector<Executor::PlanData*, ltt::integral_constant<bool, true> > const&, TRexCommonObjects::TRexApiError&, Executor::ExecutionInfo const&)+0x33 at ptime/query/plan_executor/trex_wrapper/trex_wrapper_body/trex_plan.cc:392 (libhdbcswrapper.so)
  26: 0x00007f84e8053d0e in Executor::X2::runPopTask(Executor::X2::PopTaskInfo&, int&, ltt::allocator&, ltt::allocator&)+0x2bea at executor/X2.cpp:2874 (libhdbexecutor.so)
  27: 0x00007f84e8049550 in Executor::X2::runPopJob(Executor::X2Job*)+0x70 at ltt/ext/hnd/releasable_handle.hpp:444 (libhdbexecutor.so)
  28: 0x00007f84e8062ba7 in Executor::X2Job::run(Execution::Context&, Execution::JobObject&)+0x423 at executor/X2.cpp:5954 (libhdbexecutor.so)
  29: 0x00007f84cac58c0b in Execution::JobObjectImpl::run(Execution::JobWorker*)+0x13d7 at Basis/Execution/impl/JobExecutorRunJob.cpp:772 (libhdbbasis.so)
  30: 0x00007f84cac6058a in Execution::JobWorker::runJob(ltt::smartptr_handle<Execution::JobObjectForHandle>&)+0x8a6 at Basis/Execution/impl/JobExecutorThreads.cpp:379 (libhdbbasis.so)
  31: 0x00007f84cac62278 in Execution::JobWorker::run(Execution::ThreadRC&)+0x744 at Basis/Execution/impl/JobExecutorThreads.cpp:1382 (libhdbbasis.so)
  32: 0x00007f84caca2fd4 in Execution::Thread::staticMainImp(Execution::Thread*)+0x610 at Basis/Execution/impl/Thread.cpp:612 (libhdbbasis.so)
  33: 0x00007f84caca95bf in Execution::pthreadFunctionWrapper(Execution::Thread*)+0x1eb at Basis/Execution/impl/ThreadInterposition.cpp:684 (libhdbbasis.so)
  34: 0x00007f84ccb156ea in start_thread+0xd8 (libpthread.so.0)
  35: 0x00007f84ca02058f in __GI___clone+0x3d (libc.so.6)
exception throw location:
```


#### [Alert] :  Persistence Errors Found!

```sql
CONNECTION ESTABLISHMENT: ABORTED
CONNECTION ESTABLISHMENT: REDIRECTED
```


#### [Alert] : Debug Trace

| MESSAGE                               | CPP_FILENAME                   | LAST_OCCURENCE       | DEBUG_MSG_COUNT |
|---------------------------------------|--------------------------------|----------------------|-----------------|
| CONNECTION ESTABLISHMENT: ABORTED     | RequestStatistics.cpp(00103)   | 2024-07-26-042221    | 40              |
| CONNECTION ESTABLISHMENT: REDIRECTED  | RequestStatistics.cpp(00103)   | 2024-07-26-042410    | 33              |

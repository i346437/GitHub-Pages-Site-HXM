---
title: HANA Inventory
hide_title: true
---

- LIVE systems
  ```spl
  | from inputlookup:"all_hana_inventory.csv"
  | search STATUS=LIVE

- No. of systems by Environment
  ```spl
  | from inputlookup:"all_hana_inventory.csv"
  | search STATUS=LIVE
  | stats count by PRODUCT, CATEGORY

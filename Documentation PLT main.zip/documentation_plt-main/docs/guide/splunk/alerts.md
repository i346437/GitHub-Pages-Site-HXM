---
title: Alerts
hide_title: true
draft: true
    # Draft documents will only be available during development
---


https://orf.cld.ondemand.com/en-US/app/database_utilities/alerts
```spl
| rest /servicesNS/-/-/saved/searches  | search title=*  author=i348761 disabled=0 action.email.to=*sap*
| rename title AS "Title" description AS "Description", search AS "Search", cron_schedule AS "Cron Schedule", action.email.to AS "Email" ,alert_comparator AS "Comparison", dispatch.earliest_time  AS "frequency", alert.severity AS  "SEV" ,author AS "Author" ,disabled AS "Disabled-True"
| eval Severity=case(SEV == "5", "Critical-5", SEV == "4", "High-4",SEV == "3", "Warning-3",SEV == "2", "Low-2",SEV == "1", "Info-1")
| table Title, Search, Description, Threshold, Comparison, "Cron Schedule", frequency, Severity, Email,Author,Disabled-True
```
---
title: New Pools
hide_title: true
---

[Capacity Request](https://sap.sharepoint.com/teams/HDBSys/Lists/CapacityIntakeRequest)

Follow the format:
| S.No | Reqst.Date | Reqstd.By                            | Priority | Reqd.By    | DC   | Environment | Application | Description       | Supporting Data                          | Additional Comments | Status    | Assgined to | Ticket           |
|------|------------|-------------------------------------|----------|------------|------|-------------|-------------|--------------------|------------------------------------------|---------------------|-----------|-------------|------------------|
| 1    | 4/30/2021  | Chanhal Ramangoudra, Somashekar Reddy | High     | 4/30/2021  | DC41 | Production  | BizX        | New pool in dc41  | We need additional pool in DC41 Prod... | DC41 NEW POOL...   | Completed | Karra, Kiran | SAO-7571,SAO-7456 |



[Stack/Pool Activation](https://confluence.successfactors.com/pages/viewpage.action?spaceKey=SSADO&title=HANA+Stack+Activation+Process#1-2070981)
---
title: Known Issue -> Parameters
hide_title: true
---

```
<service>.ini -> [threads] -> default_stack_size_kb
<service>.ini -> [threads] -> worker_stack_size_kb
```
In LMS, Stackallocator is increased due to this parameter, especially on LMS Sales we have a huge number of schema with many FTIs and each FTI has its own queue / thread. So we unset them.

Ref# [1999997 - FAQ: SAP HANA Memory](https://arc.net/l/quote/pjjnmwik)
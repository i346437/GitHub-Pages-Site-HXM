---
title: SAP Notes/ SQL Collectiom
hide_title: true
---

    -   [FAQ: SAP HANA Memory](https://me.sap.com/notes/1999997)
    -   [FAQ: SAP HANA Workload Management](https://me.sap.com/notes/2222250)
    -   [SQL Statement Collection: "HANA_Memory_OutOfMemoryEvents" report for SAP HANA](https://me.sap.com/notes/3456746)

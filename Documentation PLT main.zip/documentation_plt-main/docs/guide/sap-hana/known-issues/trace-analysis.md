---
title: Trace Analysis
hide_title: true
---

```sql
1: PersistenceLayer::UnbufferedFileException::UnbufferedFileException
2: PersistenceLayer::UnbufferedFileFS::close
3: PersistenceLayer::UnbufferedFileFS::~UnbufferedFileFS
4: PersistenceLayer::UnbufferedFileFS::~UnbufferedFileFS
5: TRexAPI::ImportExportImpl::exportLobs
```
*Exception handling related to file system error when exporting table containing LOB column(s). The unhandled exception contains the above call stack.*

---

```sql
[23891]{322414}[-1/-1] 2024-08-07 09:00:11.987269 e Memory           mmReportMemoryProblems.cpp(02082) : Composite limit violation (OUT OF MEMORY) occurred.
Composite limit=60gb (64424509440b)
Root allocator name=Connection/322414/Statement/1384758337820573
MemoryType: NearDRAM
Host: pc23hdbly401
Executable: hdbindexserver
PID: 61959
Failed to allocate 26.11gb (28041070896b).
Allocation failure type: STATEMENT_MEMORY_LIMIT_FROM_GLOBAL_CONFIG
```
*STATEMENT_MEMORY_LIMIT_FROM_GLOBAL_CONFIG - Statement memory limit configured with parameter statement_memory_limit - [3410944 - OOM event in HANA database](https://me.sap.com/notes/3410944/E)*

---

```sql
[35676]{-1}[-1/-1] 2024-08-07 08:09:51.584067 d SQLSession       RequestStatistics.cpp(00103) : CONNECTION ESTABLISHMENT: ABORTED
OPEN_TS=1723018191672159 (2024-08-07 08:09:51.672159)
TOTAL_ELAPSED_TIME=5005471
- TOTAL_CLIENT_ROUND_TIME=0
- TOTAL_SERVER_TIME=5005471
[0] INITIAL REQUEST TIME=5005471 - ABORTED
  - RECEIVE_TS=0 (<none>)
  - RECEIVE_TIME=0
    - RECEIVE_CALL_TIME=0
    - RECEIVE_CALL_COUNT=0
  - SERVER_PROCESSING_TIME=5005471
    - JOB_DISPATCH_WAIT_TIME=87
  - SEND_TIME=0
  - SENT_TS=0 (<none>)
```
*As per [2000000 - FAQ: SAP HANA Performance Optimization](https://me.sap.com/notes/2000000/E), Indicates time spent within SAP HANA server.  Overall connection establishment time is around 5 seconds and most of the time is spent with the SAP HANA database server (+ network transfer time).*

---


---
title: Persistence
hide_title: true
---

#### From Traces


```sql
[876]{-1}[-1/-1] 2024-07-30 12:32:43.667265 w commlib          commlibImpl.cpp(00924) :   10: 0x00007f40c92d6c08 in PersistenceLayer::NewdbRemoteNodeAccessor::executeRemoteOperation(TransactionManager::ConsistentView const&, unsigned int, unsigned int, void const*, unsigned long, void*, unsigned long, ltt::vector<char>*, unsigned long)+0x124 at PersistenceLayer/NewdbRemoteNodeAccessor.cpp:323 (libhdbpersistence.so)
  11: 0x00007f40c5156fd7 in DataAccess::ReplicationSavepointCoordinatorBase::executeOperation(unsigned int, unsigned int, DataAccess::SavepointCoordinatorOperation&, DataAccess::SavepointCoordinatorMessageReply&)+0xa3 at DataAccess/impl/DisasterRecoverySavepointCoordinator.cpp:1385 (libhdbdataaccess.so)
  12: 0x00007f40c515eb42 in DataAccess::ReplicationSavepointCoordinatorClient::sendCommandGetReplayStatus(unsigned int, unsigned int, DataAccess::ReplayInfo&)+0x150 at DataAccess/impl/DisasterRecoverySavepointCoordinator.cpp:2739 (libhdbdataaccess.so)
  13: 0x00007f40c50bb7b6 in DataAccess::DisasterRecoverySecondaryHandlerImpl::getReadAccessStatus(unsigned int, unsigned int, DataAccess::ReadAccessStatus&)+0x72 at DataAccess/impl/DisasterRecoverySecondaryImpl.cpp:2826 (libhdbdataaccess.so)
  14: 0x00007f40f0c0662a in NameServer::DRRequestHandler::drSecondaryActiveStatus(NameServer::Response&, NameServer::Request&)+0xb46 at TREXNameServer/DRUtils/DRRequestHandler.cpp:3412 (libhdbns.so)
  15: 0x00007f40f0da9c06 in NameServer::TREXNameServer::processRequest(NameServer::Request const&, NameServer::Response&)+0x1a2 at TREXNameServer/NSRequestHandler.h:32 (libhdbns.so)
  16: 0x00007f40f0daaaa4 in NameServer::TREXNameServer::handle(TrexNet::Request&, TrexService::HandlerContext&)+0x980 at TREXNameServer/TREXNameServer.cpp:1131 (libhdbns.so)
  17: 0x0000563856378d87 in TRexAPI::TREXIndexServer::handle(TrexNet::Request&, TrexService::HandlerContext&)+0xd83 at TREXIndexServer2/TREXIndexServer.cpp:3119 (hdbnameserver)
  18: 0x00007f40c6f97fc2 in TrexNet::Ext::WorkerThread::runImpl(TrexNet::Channel*, ltt::smartptr_handle<TrexService::Service>&, ltt::basic_string<char, ltt::char_traits<char>, 39ul>&, Synchronization::Mutex*, unsigned long&)+0x2440 at TrexNet/Ext/WorkerThread.cpp:699 (libhdbbasement.so)
  19: 0x00007f40c6f9858a in TrexNet::Ext::RequestJob::run(Execution::Context&, Execution::JobObject&)+0xd6 at TrexNet/Ext/WorkerThread.cpp:233 (libhdbbasement.so)
  20: 0x00007f40c2a58c0b in Execution::JobObjectImpl::run(Execution::JobWorker*)+0x13d7 at Basis/Execution/impl/JobExecutorRunJob.cpp:772 (libhdbbasis.so)
  21: 0x00007f40c2a6058a in Execution::JobWorker::runJob(ltt::smartptr_handle<Execution::JobObjectForHandle>&)+0x8a6 at Basis/Execution/impl/JobExecutorThreads.cpp:379 (libhdbbasis.so)
  22: 0x00007f40c2a62278 in Execution::JobWorker::run(Execution::ThreadRC&)+0x744 at Basis/Execution/impl/JobExecutorThreads.cpp:1382 (libhdbbasis.so)
  23: 0x00007f40c2aa2fd4 in Execution::Thread::staticMainImp(Execution::Thread*)+0x610 at Basis/Execution/impl/Thread.cpp:612 (libhdbbasis.so)
  24: 0x00007f40c2aa95bf in Execution::pthreadFunctionWrapper(Execution::Thread*)+0x1eb at Basis/Execution/impl/ThreadInterposition.cpp:684 (libhdbbasis.so)
  25: 0x00007f40c497b6ea in start_thread+0xd8 (libpthread.so.0)
  26: 0x00007f40c1e2058f in __GI___clone+0x3d (libc.so.6)
```

```sql
[46847]{343521}[1442/75063523070] 2024-07-25 19:58:38.609263 e SERVER_TRACE     TRexApiAdmin.cpp(06495) : Alter load unit failed for BHDT01::SFV4_ONBQA1:BE_TLM_TIME_ACC_DET_AUD (t 5068693) with error: Column id 201 of TableName='SFV4_ONBQA1:BE_TLM_TIME_ACC_DET_AUD' (tableOID=5068693), ContainerID=0xfe08461623 is in old persistence format. Please execute a delta merge and re-execute the operation.(6010944)
```

```sql
[160500]{351046}[255/-1] 2024-07-26 08:22:23.769866 e attributes       AttributeEngine.cpp(00539) :    
3: 0x00007f84e0429448 in AttributeEngine::AttributeApi::getOpenIndex(AttributeEngine::AttributeStoreHandle&, TrexBase::IndexName const&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*)+0x3e4 at AttributeEngine/AttributeEngine.h:257 (libhdbcs.so)
4: 0x00007f84e042d4f7 in AttributeEngine::AttributeApi::getOpenAttribute(AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeValueContainerHandle&, TrexBase::IndexName const&, unsigned int, AttributeEngine::AttributeStoreLockMode, AttributeEngine::LazyMode)+0x23 at AttributeEngine/AttributeApi.cpp:2785 (libhdbcs.so)
[102409]{351046}[255/-1] 2024-07-26 08:22:23.769884 e attributes       AttributeEngine.cpp(00539) :    3: 0x00007f84e0429448 in AttributeEngine::AttributeApi::getOpenIndex(AttributeEngine::AttributeStoreHandle&, TrexBase::IndexName const&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*)+0x3e4 at AttributeEngine/AttributeEngine.h:257 (libhdbcs.so)
[160500]{351046}[255/-1] 2024-07-26 08:22:23.769866 e attributes       AttributeEngine.cpp(00539) :    2: 0x00007f84e063abc7 in AttributeEngine::AttributeEngine::openIndexfromStorage(TrexBase::IndexName const&, AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*, AttributeEngine::StoreMapBucket&, ltt::smartptr_handle<AttributeEngine::AttributeStore>&)+0x113 at AttributeEngine/AttributeEngine.cpp:527 (libhdbcs.so)
[102409]{351046}[255/-1] 2024-07-26 08:22:23.769884 e attributes       AttributeEngine.cpp(00539) :    2: 0x00007f84e063abc7 in AttributeEngine::AttributeEngine::openIndexfromStorage(TrexBase::IndexName const&, AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*, AttributeEngine::StoreMapBucket&, ltt::smartptr_handle<AttributeEngine::AttributeStore>&)+0x113 at AttributeEngine/AttributeEngine.cpp:527 (libhdbcs.so)
[160500]{351046}[255/-1] 2024-07-26 08:22:23.769866 e attributes       AttributeEngine.cpp(00539) :    1: 0x00007f84e0639c11 in AttributeEngine::AttributeStore::AttributeStore(ltt::allocator&, TrexBase::IndexName const&, PersistenceLayer::IndexStorageLocation const&, bool, DataAccess::PersistenceSession*, bool, bool, bool)+0x440 at AttributeEngine/AttributeStore.cpp:1288 (libhdbcs.so)
[102409]{351046}[255/-1] 2024-07-26 08:22:23.769884 e attributes       AttributeEngine.cpp(00539) :    1: 0x00007f84e0639c11 in AttributeEngine::AttributeStore::AttributeStore(ltt::allocator&, TrexBase::IndexName const&, PersistenceLayer::IndexStorageLocation const&, bool, DataAccess::PersistenceSession*, bool, bool, bool)+0x440 at AttributeEngine/AttributeStore.cpp:1288 (libhdbcs.so)
[160500]{351046}[255/-1] 2024-07-26 08:22:23.769866 e attributes       AttributeEngine.cpp(00539) : :PersistenceSession*, bool, bool, bool)+0x440 at AttributeEngine/AttributeStore.cpp:1288 (libhdbcs.so)
   5: 0x00007f84e063abc7 in AttributeEngine::AttributeEngine::openIndexfromStorage(TrexBase::IndexName const&, AttributeEngine::AttributeStoreHandle&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*, AttributeEngine::StoreMapBucket&, ltt::smartptr_handle<AttributeEngine::AttributeStore>&)+0x113 at AttributeEngine/AttributeEngine.cpp:527 (libhdbcs.so)
   6: 0x00007f84e0429448 in AttributeEngine::AttributeApi::getOpenIndex(AttributeEngine::AttributeStoreHandle&, TrexBase::IndexName const&, AttributeEngine::AttributeStoreLockMode, DataAccess::PersistenceSession*)+0x3e4 at AttributeEngine/AttributeEngine.h:257 (libhdbcs.so)
```

```sql
[125092]{354135}[427/72604481540] 2024-07-25 00:12:15.377216 e ImportExport     ImportExport.cpp(13888) : Exception in copy location exception  1: no.70028001  (PersistenceLayer/FsUnbufferedFile.cpp:184) TID: 125092
    Unknown filesystem error on /lms_IRT_refresh/hana/src/FD54703BD5E34AF587BA29E2CC037052/index/TAKEDAPH035_PROD_TMS/PA/PA_CBT_STUD_CPNT_MOD_OBJ/mainData/attribute_214.data: os code: 4 os message: Interrupted system call
exception throw location:
   0: 0x00007f9faca0780a in PersistenceLayer::UnbufferedFileException::UnbufferedFileException(char const*, int, int, ltt::basic_string_funcarg<char, ltt::char_traits<char>, 39ul> const&)+0x6 at PersistenceLayer/UnbufferedFile.cpp:255 (libhdbpersistence.so)
   1: 0x00007f9fac98d574 in PersistenceLayer::UnbufferedFileFS::UnbufferedFileFS(PersistenceLayer::StorageLocation const&, PersistenceLayer::STORAGE_TYPE, ltt::basic_string_funcarg<char, ltt::char_traits<char>, 39ul> const&, PersistenceLayer::OPEN_MODE, PersistenceLayer::SYNC_MODE)+0x210 at PersistenceLayer/FsUnbufferedFile.cpp:184 (libhdbpersistence.so)
   2: 0x00007f9faca07c80 in PersistenceLayer::UnbufferedFile::getFile(PersistenceLayer::StorageLocation const&, PersistenceLayer::STORAGE_TYPE, ltt::basic_string_funcarg<char, ltt::char_traits<char>, 39ul> const&, PersistenceLayer::OPEN_MODE, PersistenceLayer::SYNC_MODE, ResourceManager::Disposition, DataAccess::PersistenceSession*, bool, TransactionManager::ConsistentView const*)+0x3e0 at PersistenceLayer/UnbufferedFile.cpp:388 (libhdbpersistence.so)
   3: 0x00007f9faca1341e in PersistenceLayer::UnifiedTableAccess::exportUTMainDataToFiles(ltt::refcounted_handle<UnifiedTable::TableContainer>&, PersistenceLayer::StorageLocation const&, DataAccess::PersistenceSession&, ltt::set<unsigned int, ltt::less<unsigned int>, ltt::rb_tree_balancier> const*)+0xa5a at PersistenceLayer/UnbufferedFile.h:512 (libhdbpersistence.so)
   4: 0x00007f9faca16b4a in PersistenceLayer::UnifiedTableAccess::copy(PersistenceLayer::StorageLocation const&, PersistenceLayer::StorageLocation const&, bool, bool, DataAccess::PersistenceSession*, ltt::set<unsigned int, ltt::less<unsigned int>, ltt::rb_tree_balancier> const*)+0x1746 at PersistenceLayer/UnifiedTableAccess.cpp:808 (libhdbpersistence.so)
   5: 0x00007f9fac9f97d7 in PersistenceLayer::SLCopyThread::copyUTContainer(PersistenceLayer::ObjectInfo const*, PersistenceLayer::StorageLocation const*, PersistenceLayer::StorageLocation const*) const+0x3d3 at PersistenceLayer/StorageLocationManager.cpp:412 (libhdbpersistence.so)
   6: 0x00007f9fac9faada in PersistenceLayer::SLCopyThread::run(void*)+0x11d6 at PersistenceLayer/StorageLocationManager.cpp:357 (libhdbpersistence.so)
 ```

 ```sql
 [100128]{-1}[10/-1] 2024-07-25 04:11:30.408411 e Crypto           RootKeyStoreConsistencyChecker.cpp(00088) : SSFS inconsistent: PERSISTENCE BACKUP LOG
[100128]{-1}[10/-1] 2024-07-25 04:11:30.403089 w Crypto           RootKeyStoreConsistencyChecker.cpp(00164) : SSFS key of type/version Persistence/0 is inconsistent (key has changed). Missing root key hash: 7b79f667bed14046fba51e8cd1089410529b0507a393606c49224d627909b4c5 (found: 2fd1f5b47b7de3fd22239739ccbb3f283057288f73a61a19624766d0266df300)
[103288]{-1}[13/-1] 2024-07-25 04:11:34.504733 w Crypto           RootKeyStoreConsistencyChecker.cpp(00164) : SSFS key of type/version Persistence/0 is inconsistent (key has changed). Missing root key hash: 7b79f667bed14046fba51e8cd1089410529b0507a393606c49224d627909b4c5 (found: 2fd1f5b47b7de3fd22239739ccbb3f283057288f73a61a19624766d0266df300)
```

```sql
[17217]{-1}[-1/-1] 2024-07-24 13:56:41.807784 w commlib          commlibImpl.cpp(00924) :   10: 0x00007f7644b27c08 in PersistenceLayer::NewdbRemoteNodeAccessor::executeRemoteOperation(TransactionManager::ConsistentView const&, unsigned int, unsigned int, void const*, unsigned long, void*, unsigned long, ltt::vector<char>*, unsigned long)+0x124 at PersistenceLayer/NewdbRemoteNodeAccessor.cpp:323 (libhdbpersistence.so)
  11: 0x00007f76409a7fd7 in DataAccess::ReplicationSavepointCoordinatorBase::executeOperation(unsigned int, unsigned int, DataAccess::SavepointCoordinatorOperation&, DataAccess::SavepointCoordinatorMessageReply&)+0xa3 at DataAccess/impl/DisasterRecoverySavepointCoordinator.cpp:1385 (libhdbdataaccess.so)
  12: 0x00007f76409afb42 in DataAccess::ReplicationSavepointCoordinatorClient::sendCommandGetReplayStatus(unsigned int, unsigned int, DataAccess::ReplayInfo&)+0x150 at DataAccess/impl/DisasterRecoverySavepointCoordinator.cpp:2739 (libhdbdataaccess.so)
  13: 0x00007f764090c7b6 in DataAccess::DisasterRecoverySecondaryHandlerImpl::getReadAccessStatus(unsigned int, unsigned int, DataAccess::ReadAccessStatus&)+0x72 at DataAccess/impl/DisasterRecoverySecondaryImpl.cpp:2826 (libhdbdataaccess.so)
  14: 0x00007f766c45762a in NameServer::DRRequestHandler::drSecondaryActiveStatus(NameServer::Response&, NameServer::Request&)+0xb46 at TREXNameServer/DRUtils/DRRequestHandler.cpp:3412 (libhdbns.so)
  15: 0x00007f766c5fac06 in NameServer::TREXNameServer::processRequest(NameServer::Request const&, NameServer::Response&)+0x1a2 at TREXNameServer/NSRequestHandler.h:32 (libhdbns.so)
  16: 0x00007f766c5fbaa4 in NameServer::TREXNameServer::handle(TrexNet::Request&, TrexService::HandlerContext&)+0x980 at TREXNameServer/TREXNameServer.cpp:1131 (libhdbns.so)
  17: 0x0000556dc52bbd87 in TRexAPI::TREXIndexServer::handle(TrexNet::Request&, TrexService::HandlerContext&)+0xd83 at TREXIndexServer2/TREXIndexServer.cpp:3119 (hdbnameserver)
  18: 0x00007f76427e8fc2 in TrexNet::Ext::WorkerThread::runImpl(TrexNet::Channel*, ltt::smartptr_handle<TrexService::Service>&, ltt::basic_string<char, ltt::char_traits<char>, 39ul>&, Synchronization::Mutex*, unsigned long&)+0x2440 at TrexNet/Ext/WorkerThread.cpp:699 (libhdbbasement.so)
  19: 0x00007f76427e958a in TrexNet::Ext::RequestJob::run(Execution::Context&, Execution::JobObject&)+0xd6 at TrexNet/Ext/WorkerThread.cpp:233 (libhdbbasement.so)
  ```
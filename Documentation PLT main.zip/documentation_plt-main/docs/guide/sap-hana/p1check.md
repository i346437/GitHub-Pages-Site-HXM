---
title: p1Check Insights
hide_title: true
---

Saved monitoring views from P1check page will be named along with datetimestamp, for eg:
```sql
select object_name from objects where schema_name='DBREPO' and object_name like '%202408%';
```
It captures below views
```M_ACTIVE_STATEMENTS
M_JOB_PROGRESS
M_SERVICE_THREADS
M_SERVICE_THREAD_SAMPLES
M_SQL_PLAN_CACHE

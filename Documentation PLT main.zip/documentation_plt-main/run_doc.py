import subprocess
import os
import shutil

def run_doc():
    build_dir = 'build'

    # Clean up the previous build if it exists
    if os.path.exists(build_dir):
        print("Cleaning up previous build...")
        shutil.rmtree(build_dir)

    # Build the site
    print("Building the site...")
    subprocess.run(['yarn', 'build'], check=True) 

    # Serve the site
    print("Serving the site...")
    subprocess.run(['yarn', 'serve'], check=True) 

if __name__ == '__main__':
    run_doc()
